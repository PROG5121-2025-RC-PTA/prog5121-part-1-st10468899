/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationandlogin;

import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class RegistrationandLogin {

    public static void main(String[] args) {
         {
    
        // Registration
        String username = JOptionPane.showInputDialog(null, "Create a username (at least 5 characters,contains an underscore):");
        if (username.length() < 5 || !username.contains("_")) {
            JOptionPane.showMessageDialog(null, "Invalid username. Username must be at least 5 characters long and contain an underscore.");
            return;
        }

        String password = JOptionPane.showInputDialog(null, "Create a password (must have 8+ characters, including uppercase, digit, and special character):");
        if (password.length() < 8 || 
    !password.matches(".*[A-Z].*") || 
    !password.matches(".*\\d.*") || 
    !password.matches(".*[!@#$%^&*(),.?\":{}|<>].*") || 
    !password.matches(".*_.*")) {

            JOptionPane.showMessageDialog(null, "Invalid password. Password must be at least 8 characters long and include uppercase, lowercase, digit, and special character.");
            return;
        }

        String phoneNumber = JOptionPane.showInputDialog(null, "Enter your phone number (format: + followed by 9 to 12 digits):");
        if (!phoneNumber.matches("^\\+\\d{2,3}\\d{4,10}$")) {
            JOptionPane.showMessageDialog(null, "Invalid phone number format,please correct the number and try again");
            return;
        }

        JOptionPane.showMessageDialog(null, "Registration successful!");

        // Login
        String loginUsername = JOptionPane.showInputDialog(null, "Enter your username:");
        String loginPassword = JOptionPane.showInputDialog(null, "Enter your password:");
        String loginPhoneNumber = JOptionPane.showInputDialog(null, "Enter your phone number:");

        if (username.equals(loginUsername) && password.equals(loginPassword) && phoneNumber.equals(loginPhoneNumber)) {
            JOptionPane.showMessageDialog(null, "Login successful! welcome");
        } else {
            JOptionPane.showMessageDialog(null, "Invalid username, password, or phone number!");
        }
    }

    
    }
}